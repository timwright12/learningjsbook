/* standard Ajax xhr function */

function getHTTPObject() {

    var xhr;

    if (window.XMLHttpRequest) { // check for support
        
        // if it's supported, use it beacuse it's better
        xhr = new XMLHttpRequest();
    
    } else if (window.ActiveXObject) { // check for the IE 6 Ajax
    
        // save it to the xhr variable
        xhr = new ActiveXObject("Msxml2.XMLHTTP");
    
    }
    
    // spit out the correct one so we can use it
    return xhr;
}

/* define the Ajax call */

function ajaxCall(dataUrl, outputElement, callback) {
    
    /* use our function to get the correct Ajax object based on support */
    var request = getHTTPObject();
    
    outputElement.innterHTML = "Loading...";

    request.onreadystatechange = function() {
        
        // check to see if the Ajax call went through
        if ( request.readyState === 4 && request.status === 200 ) {
            
            // save the ajax response to a variable
            var contacts = JSON.parse(request.responseText);
            
            // make sure the callback is indeed a function before executing it
            if(typeof callback === "function"){
            
                callback(contacts);
            
            } // end check
    
        } // end ajax status check
    
    } // end onreadystatechange
    
    request.open("GET", dataUrl, true);
    request.send(null);

}
