/*
    Listing 4.8.1
*/

// target the “about” link and apply a class to it’s parent list item
document.getElementById("about").parentNode.setAttribute("class", "active");



/*
    Listing 4.8.2
*/

// get “about” parent, then it’s previous sibling and apply a class
document.getElementById("about").parentNode.previousSibling.setAttribute("class", "previous");

// get “about” parent, then it’s next sibling and apply a class
document.getElementById("about").parentNode.nextSibling.setAttribute("class", "next");



/*
    Listing 4.8.4
*/

// travel to the first node and add the class
document.getElementById("nav").firstChild.setAttribute("class", "first");

// travel to the last node and add a class
document.getElementById("nav").lastChild.setAttribute("class", "last");