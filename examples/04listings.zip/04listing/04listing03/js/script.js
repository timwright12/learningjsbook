/*
    listing 4.3.1
*/

document.getElementsByTagName("p");




/*
    listing 4.3.2
*/

document.getElementsByTagName("p").length;
// will return 3

// checking the length before executing script
if(document.getElementsByTagName("p").length > 0) {
	// its returns “3”, and 3 is greater than “0”, so we’re good to go.
}




/*
    listing 4.3.3
*/

// the first paragraph using the item method
document.getElementsByTagName("p").item(0);

// the first paragraph with array syntax
document.getElementsByTagName("p")[0];

// the second paragraph with the item method
document.getElementsByTagName("p").item(1);

// the second paragraph with array syntax
document.getElementsByTagName("p")[1];




/*
    listing 4.3.4
*/

// checking the length before executing script
if(document.getElementsByTagName("p").length > 0) {
	// its returns “3”, and 3 is greater than “0”, so we’re good to go.
	
// let’s access some elements with array the syntax
    document.getElementsByTagName("p")[0];
    document.getElementsByTagName("p")[2];

}
