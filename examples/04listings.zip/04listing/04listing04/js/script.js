/*
    Listing 4.4.1
*/

// returns all elements with a class of drop cap
document.getElementsByClassName("dropcap");

// returns all elements with both “drop cap" and “huge" classes (1 in our example)
document.getElementsByClassName("dropcap huge");

// returns all element classed with “huge" that are inside elements classed with “drop cap" (1 element in our example – the span)
document.getElementById("extra").getElementsByClassName("huge")[0];