/*
    Listing 4.6.1
*/

// first we target the element and check if it has a class on it
if(document.getElementById("plc").hasAttribute("class")) {
	
// after we know a class exists, we can then get the value
	document.getElementById("plc").getAttribute("class");

	// this would return the value of "show", which is the class on our image
}




/*
    Listing 4.6.2
*/

// replace the current class with a value of "hidden"
document.getElementById("plc").setAttribute("class", "hidden");

// add a new attribute to the image
document.getElementById("plc").setAttribute("title", "we moved this element off screen");




/*
    Listing 4.6.4
*/

// first we target the element and check if it has a class on it
if(document.getElementById("plc").hasAttribute("class")) {
	
    // after we know a class exists, we can then remove it
	document.getElementById("plc").removeAttribute("class");

}
