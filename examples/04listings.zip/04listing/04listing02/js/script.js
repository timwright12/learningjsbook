document.getElementById("homelink");
document.getElementById("header");