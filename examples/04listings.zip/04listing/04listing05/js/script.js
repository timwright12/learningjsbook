/*
    Listing 4.5.1
*/

// get the header ID element
document.querySelector("#header");

// get the first element with a drop cap class
document.querySelector(".dropcap")

// get all the paragraphs with a "drop cap" class – produces a nodeList
document.querySelectorAll(".dropcap");

// get all elements with a class or "drop cap" OR "huge"
document.querySelectorAll(".dropcap, .huge");

// get all paragraphs that have a class
document.querySelectorAll("p[class]");