/*
    Listing 4.7.1
*/

// targeting the text node
document.getElementById("target-area").innerHTML;

// changing the content in the text node – you can jump straight to this.
document.getElementById("target-area").innerHTML = "<p>hello world</p>";