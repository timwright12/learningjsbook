/*
    Listing 4.9.1
*/

// store the target area to a variable to keep things neat
var targetArea = document.getElementById("target-area");

// create our <p> element
var p = document.createElement("p");
var text = document.createTextNode("this was a generated paragraph");

// create a text node inside the <p>, note that we’re using a variable “p” here
var snippet = p.appendChild(text);

//insert our generated paragraph into the DOM
targetArea.appendChild(snippet);




/*
    Listing 4.9.3
*/

// store the target area to a variable to keep things neat
var targetArea = document.getElementById("target-area");

// store the tagline in a variable as well
var tagline = document.getElementById("tagline");

// remove it from the DOM
targetArea.removeChild(tagline);