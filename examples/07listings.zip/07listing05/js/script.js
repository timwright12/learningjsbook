(function(){

    var body = document.getElementsByTagName("body")[0];
    
    // declare an object to hold touch controls
    var touchControls = {
    
        pokeTheScreen : function(e){
            
            // output another message to the body
            body.innerHTML += "you just poked me, how rude!<br>";
    
        },
        stopPokingTheScreen: function(){
    
            // output another message to the body
            body.innerHTML += "please don’t to that again.<br><br>";
    
        },
        showMovement : function(){
            
            // output a message to the body
            body.innerHTML += "moving!!<br>";
    
        },
        changedOrientation: function(){
        
            // clear the body element out
            body.innerHTML = "";
        
        }

    } // end object
    
    body.addEventListener("touchstart", touchControls.pokeTheScreen, false);
    body.addEventListener("touchend", touchControls.stopPokingTheScreen, false);
    body.addEventListener("touchmove", touchControls.showMovement, false);
    body.addEventListener("orientationchange", touchControls.changedOrientation, false);   

})();