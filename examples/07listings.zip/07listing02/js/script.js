/* wrap it in an anonymous function to contain the variables */
(function(){
    
    // HTML: <button type="button" id="btn">a button</button>
    
    // save the button to a variable
    var btn = document.getElementById("btn");
    
    // attach a "click" listener to the button
    btn.addEventListener("click", function(){ 
        
        // alert inside this anonymous callback function    
        alert('clicked the button');
    
    }, false);

})();