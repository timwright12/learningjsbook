function zerbraStripe(wrapper, elToStripe){

    $(wrapper).find(elToStripe + ':odd').css({
        'background':'#ccc'
    });

}

$(document).ready( function () {
    
    var output = $('#output'),
        p = output.find('p');
    
    zerbraStripe(output, p);

});