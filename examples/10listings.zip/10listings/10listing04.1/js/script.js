// enclose the plugin so no variables leak out
(function($){
    
    // define and name the plugin
    $.fn.zerbraStripe = function(options) {  
        
        // define default options
        var defaults = {
        	elToStripe: "li"
        }
        
        // let options be customized by the user
        var options = $.extend(defaults, options);
        
        // loop through each element you're attaching the plugin to
        return this.each(function() {
            
            // use the attached elemtn and option value      
        	$(this).find(options.elToStripe + ':odd').css({
                'background':'#ccc'
            });
        
        });  

    };  

})(jQuery);

$(document).ready( function () {
    
    // attached zebra strip plugin to the #output div
    $('#output').zerbraStripe({
        elToStripe: "p" // if you want to change the option (we didn't)
    });

});