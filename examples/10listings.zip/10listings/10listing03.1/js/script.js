$(document).ready(function () {

    $.ajax({
        type: 'GET', // set request type GET or POST
        url: 'data/contacts.json', // data URL
        dataType: 'json', // type: xml, json, script, or html
        success: function(data) {
            
            // if the call is a success do this
            console.log(data.addressBook);
        
        },
        error: function () {
            
            // if the call fails do this
            alert('ajax error');
            
        }
    });

});