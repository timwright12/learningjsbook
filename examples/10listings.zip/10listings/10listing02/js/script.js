$(document).ready(function () {

    var container = $("#container");
    var module = $(".module");
    
    // travels up one level
    $(".module").parent().addClass('module-parent');
    
    // travels up multiple levels
    $("p").parents("#container").addClass('p-parents');
    
    // travels down
    $("#container").find(".module").addClass('container-find'); 
    
    // travels sideways
    module.siblings(".module").addClass('module-siblings'); 
    
    // get first module
    module.first().addClass('first-module'); 
    
    // get next module
    module.first().next().addClass('second-module'); 
    
    // get last module
    module.last().addClass('last-module'); 
    
    // get previous module
    module.last().prev().addClass('second-to-last-module');
    
    // add style via jQuery
    $('.module').css({
        'height': '300px'
    });
    
    // bind a click event to the only button on the page
    $('button').click(function () {
        
        // animate all the heights of each module to 0
        $('.module').animate({
            'height': '0px'
        }, 500, function () {
            
            // after the animation is complete, change the button text
            $('button').text('now what?');            
        
        }); // close animate anonymous callback function
    
    }); // close click anonymous callback function

});