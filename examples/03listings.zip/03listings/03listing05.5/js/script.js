/* store family member names in an array */
var family = [
   "joan",
   "charlie",
   "peter",
   "christine",
   "anna",
   "tim" /* this is me! */
];

/* save the variable passed into the function as a more reasonable name */
var people = family,
	peopleCount = people.length,
    i;

/* checking to make sure there are people in the list */
if (peopleCount > 0) {

    /* loop through each person */
    for (i = 0; i < peopleCount; i = i + 1) {
    
        /* this represents 1 person */
        var person = people[i];
        
        /* if the name if "tim" or "christine", do something otherwise alert the name */
		switch(person){
			case "tim":
				alert(person + ", this is me");
				break;
			
			case "christine":
				alert(person + ", my sister");
				break;
				
			default :
				alert(person);
		}
    }
}
