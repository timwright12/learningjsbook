/* defining your object aka naming this group of functions */
var getInformation = {

    /* first method (function inside an object) is called "names" */
    "names": function() {
        "use strict";

        alert("get the names");
    },

    /* second method is called "checkForTim" */
    "checkForTim": function() {
        
        "use strict";

        alert("checking for tim");

    }
};

/* get the names on load */
window.addEventListener("load", getInformation.names, false);

/* check for Tim on click */
document.addEventListener("click", getInformation.checkForTim, false);
