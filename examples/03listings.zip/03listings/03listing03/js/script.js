/* save my name */
var myName = "tim";

/* adding a variable string to a text string */
alert(myName + ", this is me");

/* adding numbers together */
alert(100 + 50); // should alert 150

/* adding strings together */
alert("100" + "50" + ", adding strings together"); // should alert 10050
