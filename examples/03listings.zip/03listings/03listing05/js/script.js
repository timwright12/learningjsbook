function getFamilyMemberNames() {
    
    "use strict";
    
    /* store family member names in an array */
	var family = [
	   "joan",
	   "charlie",
	   "peter",
	   "christine",
	   "anna",
	   "tim" /* this is me! */
	];

	var peopleCount = family.length;
	var i;
	
	/* checking to make sure there are people in the list */
	if (peopleCount > 0) {
	
	    /* loop through each person */
	    for (i = 0; i < peopleCount; i = i + 1) {
	    
	        /* this represents 1 person */
	        var person = family[i];
	        
	        /* if the name if "tim", do something else */
	        if (person === "tim") {
	        	alert(person + ", this is me!");
	        } else {
	        	alert(person);
			}
	    }
	}
}

/* call the function */
getFamilyMemberNames();