/* using a native javaScript method to call an anonymous function as a callback*/

window.addEventListener("load", function(){
	alert("callback function");	
}, false);