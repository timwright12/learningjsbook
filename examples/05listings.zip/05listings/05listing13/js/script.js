/* set localStorage */
localStorage.setItem("favoriteSandwich", "Meatball");

/* get localStorage */
var sandwich = localStorage.getItem("favoriteSandwich"); // returns Meatball

alert(sandwich);

/* remove localStorage */
localStorage.removeItem("favoriteSandwich"); // returns a happy mom :-)