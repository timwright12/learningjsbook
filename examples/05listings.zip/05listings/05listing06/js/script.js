/* use short hand brackets to declare the array */
var favoriteSandwiches = [];

/* manually assign values to the array and set the index */
favoriteSandwiches[0] = "Egg, Sausage and Cheese";
favoriteSandwiches[1] = "Turkey Club";
favoriteSandwiches[2] = "Meatball";

alert(favoriteSandwiches[1]); // Turkey Club