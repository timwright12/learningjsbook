/* Storing a count of how many sandwiches were eaten */
var mondaySandwichCount = 3;
var tuesdaySandwichCount = 1.5; // Gave half my sandwich away
var wednesdaySandwichCount = 2;
var thursdaySandwichCount = -1; // got sick Thursday
var fridaySandwichCount = 6; // recovered strong on Friday

/* alert the total number of sandwiches I ate this week (11.5) */
alert(mondaySandwichCount + tuesdaySandwichCount + wednesdaySandwichCount + thursdaySandwichCount + fridaySandwichCount);
