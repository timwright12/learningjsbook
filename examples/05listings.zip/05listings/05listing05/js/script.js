var favoriteSandwiches = ["Egg, Sausage and Cheese", "Turkey Club", "Meatball"];

/* index build automatically for you when combining array declarations and as-signment */

/* commented out - no need to delare
favoriteSandwiches[0] = “Egg, Sausage and Cheese”;
favoriteSandwiches[1] = “Turkey Club”;
favoriteSandwiches[2] = “Meatball”;
*/

alert(favoriteSandwiches[1]); // Turkey Club
