/* JSON Object */

var favoriteSandwiches = {

    "breakfast" : [
        {
            "name": "Egg, Sausage and Cheese",
            "bread": "English Muffin"
        },
        {
            "name": "Egg Whites on Flatbread",
            "bread": "Flatbread"
        }
    ],
    "lunch" : [
        {
            "name": "Turkey Club",
            "bread": "Wheat Bread"
        },
        {
            "name": "Grilled Cheese",
            "bread": "White Bread"
        }
    ],
    "dinner" : [
        {
            "name": "Meatball",
            "bread": "Kaiser Roll"
        },
        {
            "name": "Hamburger",
            "bread": "Hamburger Roll"
        }
    ]
};

/* stringify the JSON object first */
var stringObject = JSON.stringify(favoriteSandwiches);

/* add the string object to localStorage */
localStorage.setItem('favoriteSandwiches', stringObject);

/* get the locally stored data */
var storedItem = localStorage.getItem("favoriteSandwiches");

/*convert it from a string, back into a JSON object*/
var convertObject = JSON.parse(storedItem);

/* prove it worked */
alert(convertObject.breakfast[0].name);
