/* declare breakfast normally */
var breakfast = ["Egg, Sausage and Cheese", "Egg Whites on Flatbread", "Egg and Cheese"];

/* declare lunch normally */
var lunch = ["Turkey Club", "Grilled Cheese", "Peanut Butter and Jelly"];

/* declare dinner normally */
var dinner = ["Meatball", "Hamburger", "Oatmeal and banana on Rye"];

/* combine all the arrays into "favorite sandwiches"*/
var favoriteSandwiches = [breakfast, lunch, dinner];

/* get data from the array */

alert(favoriteSandwiches[0][1]); // Egg Whites on Flatbread

alert(favoriteSandwiches[1][0]); // Turkey Club

alert(favoriteSandwiches[2][1]); // Hamburger