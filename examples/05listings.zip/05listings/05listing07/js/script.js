var favoriteSandwiches = [];

/* manually set the values */
favoriteSandwiches["breakfast"] = "Egg, Sausage and Cheese";
favoriteSandwiches["lunch"] = "Turkey Club";
favoriteSandwiches["dinner"] = "Meatball";

alert(favoriteSandwiches["lunch"]); // Turkey Club