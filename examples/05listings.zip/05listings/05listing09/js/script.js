/* declare breakfast normally */
var breakfast = ["Egg, Sausage and Cheese", "Egg Whites on Flatbread", "Egg and Cheese"];

/* add a Jalapeño bagel and ham to the breakfast array */
breakfast.push("Jalapeño Bagel & Ham");

/* alert the whole array */
alert(breakfast);

/* pull out the newest array member */
alert(breakfast[3]);