if(typeof window.localStorage != 'undefined'){
    
    // do stuff with localStorage
    alert('your browser supports localStorage');
    
} else {

    // do stuff with cookies instead
    alert('no support, oh well. Maybe cookies instead?');

}