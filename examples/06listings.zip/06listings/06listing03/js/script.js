function sayHello(greeting, exitStatement){

    /* add some passion to these dry arguments */
    var newGreeting = greeting + "!",
        newExitStatement = exitStatement + "!!";

    /* return the arguments in an array */
    return [newGreeting, newExitStatement];

}

function startle(polite, rude){

    /* call the sayHello function, with arguments and same each response to a variable */
    var greeting = sayHello(polite, rude)[0],
        exit = sayHello(polite, rude)[1];
    
    /* alert the variables that have been passed through each function */
    alert(greeting + ' -- ' + exit);

}

/* call the function with our arguments defined */
startle('thank you', 'you stink');
