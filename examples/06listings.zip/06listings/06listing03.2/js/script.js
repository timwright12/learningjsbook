/* set up your anonymous function */
(function(){

    /* define a variable inside the function */
     var greeting = "Hello Tim";
     
     /* access the variable inside the function */
     alert('in scope: ' + greeting);

})();

/* try and access that variable outside the function scope */
alert('out of scope: ' + typeof(greeting));