/* declare the function */
function sayHello(message){
    alert(message); // “message” is also an argument in the “alert” method
}

/* call it a couple times with different messages */
sayHello("Hey there, you stink!");
sayHello("I feel bad I just said that.");