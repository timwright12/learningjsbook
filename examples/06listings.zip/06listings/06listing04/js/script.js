var addressBookMethods = {

    sayHello: function(message){

        return message;

    },
    startleTheUser: function(){

        alert(addressBookMethods.sayHello("hey there, called from a method"));

    }

}

/* call the function */
addressBookMethods.startleTheUser();
