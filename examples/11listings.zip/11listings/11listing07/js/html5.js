(function(){
    
    var battery = navigator.battery,
        body = document.getElementsByTagName("body")[0];  
  
    function updateBatteryStatus() {  
        
        /* Returns 0 if the battery is empty and the system is about to suspend. 
        Returns 1.0 if the battery is full, if the implementation is unable 
        to report the battery's level, or if there is no battery attached to the system. */
        body.innerHTML += "<p>Battery level: " + battery.level * 100 + "%</p>";
        
        /* Returns true if the battery is charging, if the state of the system's 
        battery is not determinable, or if no battery is attached to the system. 
        Returns false if the battery is discharging */
        body.innerHTML += "<p>Battery is charging: " + battery.charging + "</p>";
        
        /* Returns positive infinity, if the battery is discharging or if the 
        implementation is unable report the remaining charging time. */
        body.innerHTML += "<p>Battery charging time: " + battery.chargingTime + "</p>";
        
        /* Returns positive infinity if the battery is charging, if the implementation
        is unable to report the remaining discharging time, or if there is no battery
        attached to the system. */
        body.innerHTML += "<p>Battery discharging time: " + battery.dischargingTime + "</p>";
 
    }  
    
    if(battery) {
    
        battery.addEventListener("chargingchange", updateBatteryStatus);  
        battery.addEventListener("levelchange", updateBatteryStatus);
    
        updateBatteryStatus();
    
    }
    
})();