(function(){

    // Check bandwidth level is supported
    var connection,
        connectionSpeed,
        images = document.querySelectorAll("img[data-large]"),
        imageCount = images.length,
        i;
    
    // create a custom object if navigator.connection isn't available
    connection = navigator.connection || { 'type': '0' };

    if(imageCount > 0 && connection.type === '0' || connection.type === '1' || connection.type === '2') {
        
        for (i = 0; i < imageCount; i = i + 1) {
            
            var obj = images[i],
                largeImg = obj.getAttribute('data-large');
            
            obj.setAttribute('src', largeImg);
            
        }
        
    }
    
    /*
        The data will be returned in a object that 
        looks something like this:
        
        {
            "connection" : [{
                "type": "WIFI"
            }]
        }
        
    */
    
    // set connectionSpeed for output values
    switch(connection.type) {
    
        case connection.CELL_3G:
            // 3G
            connectionSpeed = 'mediumbandwidth';
            break;
            
        case connection.CELL_2G:
            // 2G
            connectionSpeed = 'lowbandwidth';
            break;
            
        default:
            // WIFI, ETHERNET, UNKNOWN
            connectionSpeed = 'highbandwidth';
    }
    
    // output to the DOM
    document.getElementsByTagName("body")[0].setAttribute('class', connectionSpeed);
    document.getElementsByTagName("body")[0].innerHTML += '<p><strong>connection:</strong> ' + connectionSpeed + '</p>';

})();