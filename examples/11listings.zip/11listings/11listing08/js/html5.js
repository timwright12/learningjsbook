(function(){
    
    // attach a click event to the button
    document.getElementById("vibrate").addEventListener("click", function(){
    
        if(navigator.vibrate) {

            // vibrate for 1 seconds, wait half a second, then vibrate 2 seconds
            navigator.vibrate([1000, 500, 2000]);

        } else {
            
            // apologize to the user for teasing them
            alert('sorry, this browser doesn\'t support the vibrate API');
        
        } // end support check
    
    }, false);

})();