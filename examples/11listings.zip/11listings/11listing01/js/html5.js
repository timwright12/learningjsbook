(function(){

    // JS here

})();