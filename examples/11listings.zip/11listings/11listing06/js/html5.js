(function () {
    
    var contacts = {
        "addressBook" : [
            {
                "name": "hillisha",
                "email": "hill@example.com",
            },
            {
                "name": "paul",
                "email": "cleveland@example.com",
            },
            {
                "name": "vishaal",
                "email": "vish@example.com",
            },
            {
                "name": "mike",
                "email": "grady@example.com",
            },
            {
                "name": "jamie",
                "email": "dusted@example.com",
            }
        ]
    };

    // create a new instance of the worker
    var worker = new Worker("js/worker.js");
    
    var btnStart = document.getElementById("start"),
        btnStop = document.getElementById("stop"),
        timerOuput = document.getElementById("timer"),
        workerOutput = document.getElementById("output"),
        num = 0;
    
    // create a script that is constantly running to block the normal flow
    setInterval(function () {
        num = num + 1;
        timerOuput.innerHTML = num;
    }, 500);
        
    // set up event listeners
    worker.addEventListener("message", function(e) {
    
        workerOutput.innerHTML += e.data;
        
    }, false);
    
    // add click event to the start button to active the worker
    btnStart.addEventListener("click", function() {
        
        worker.postMessage(contacts); // send contacts data to the worker
    
    }, false);
    
    // add a click event to the stop button to terminate th worker
    btnStop.addEventListener("click", function() {
        
        worker.terminate();
        btnStart.setAttribute("disabled", "disabled");
        
        alert("worker has been terminated");
        
    }, false);
    
})();