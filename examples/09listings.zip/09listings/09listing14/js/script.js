/* wrap script in an anonymous function because we do that */

(function(){
    
    "use strict";
    
    var body = document.getElementsByTagName("body")[0], // target element
        partyStarter = "Starlen", // name of the person running the party
        peopleCount = 10, // the amount of people coming to the party
        pizzaCount = 4, // the amount of pizza partyStarter is ordering
        sliceCount = pizzaCount * 8, // the amount of slices available
        fairness = sliceCount / peopleCount;

    // make sure people are coming and pizza is being ordered
    
    if(peopleCount > 0 && pizzaCount > 0) {
        
        // output the comments
        body.innerHTML += "<p>Dear " + partyStarter + ", Each person can have " + fairness + " pieces of pizza</p>";
        
    } else {
        
        // create a fallback message
        body.innerHTML += "<p>You need to either invite people or order pizza</p>";
        
    }

})(); // close anonymous function