function calculator(a, b, c) {

    // do some math for us
    return (a + b) * c;

}

(function (){

    // save the result to a variable
    var result = calculator(1, 2, 3);
    
    alert(result); // returns 9

})();